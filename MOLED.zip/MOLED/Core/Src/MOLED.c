#include "stdio.h"
#include "main.h"
#include "MOLED.h"
#include "gpio.h"
#include "MOLEDfont.h"

PAINT Paint;

void OLED_SCL_CLr()
{
    HAL_GPIO_WritePin(SCL_GPIO_Port,SCL_Pin,RESET);
}
void OLED_SCL_Set()
{
    HAL_GPIO_WritePin(SCL_GPIO_Port,SCL_Pin,SET);
}

void OLED_SDA_Clr()
{
    HAL_GPIO_WritePin(SDA_GPIO_Port,SDA_Pin,RESET);
}
void OLED_SDA_Set()
{
    HAL_GPIO_WritePin(SDA_GPIO_Port,SDA_Pin,SET);
}

void OLED_RES_Clr()
{
    HAL_GPIO_WritePin(RES_GPIO_Port,RES_Pin,RESET);
}
void OLED_RES_Set()
{
    HAL_GPIO_WritePin(RES_GPIO_Port,RES_Pin,SET);
}

void OLED_DC_Clr()
{
    HAL_GPIO_WritePin(DC_GPIO_Port,DC_Pin,RESET);
}
void OLED_DC_Set()
{
    HAL_GPIO_WritePin(DC_GPIO_Port,DC_Pin,SET);
}

void OLED_CS_Clr()
{
    HAL_GPIO_WritePin(INK_CS_GPIO_Port,INK_CS_Pin,RESET);
}
void OLED_CS_Set()
{
    HAL_GPIO_WritePin(INK_CS_GPIO_Port,INK_CS_Pin,SET);
}

int OLED_BUSY()
{
    return HAL_GPIO_ReadPin(BUSY_GPIO_Port,BUSY_Pin);
}

void OLED_WR_Bus(uint8_t dat)
{
    uint8_t i;
    OLED_CS_Clr();
    for (i = 0; i < 8; i++)
    {
        OLED_SCL_CLr();
        if(dat & 0x80)
        {
            OLED_SDA_Set();
        }
        else
        {
            OLED_SDA_Clr();
        }
        OLED_SCL_Set();
        dat<<=1;
    }
    OLED_CS_Set();
}

void OLED_WR_REG(uint8_t reg)//写操作命令
{
    OLED_DC_Clr();//拉低电平代表此时是命令
    OLED_WR_Bus(reg);
    OLED_DC_Set();//拉高电平代表此时是数据
}

void OLED_WR_DATA8(uint8_t data)//写入数据
{
    OLED_WR_Bus(data);
}

void Epaper_READBUSY()
{
    while(1)
    {
        if(OLED_BUSY() == 0)
        {
            break;
        }
    }
}

void EPD_Update(void)
{
    OLED_WR_REG(0X22);
    OLED_WR_REG(0x22); //Display Update Control
    OLED_WR_DATA8(0xF7);
//OLED_WR_DATA8(0xFF);
    OLED_WR_REG(0x20);  //Activate Display Update Sequence
    Epaper_READBUSY();
}

void OLED_GUIInit(void)
{
    OLED_RES_Clr();
    HAL_Delay(20);
    OLED_RES_Set();
    HAL_Delay(20);

    Epaper_READBUSY();
    OLED_WR_REG(0X12);
    Epaper_READBUSY();

    OLED_WR_REG(0x01); //Driver output control
    OLED_WR_DATA8(0xC7);
    OLED_WR_DATA8(0x00);
    OLED_WR_DATA8(0x01);

    OLED_WR_REG(0x11); //data entry mode
    OLED_WR_DATA8(0x01);

    OLED_WR_REG(0x44); //set Ram-X address start/end position
    OLED_WR_DATA8(0x00);
    OLED_WR_DATA8(0x18);    //0x0F-->(15+1)*8=128

    OLED_WR_REG(0x45); //set Ram-Y address start/end position
    OLED_WR_DATA8(0xC7);   //0xF9-->(249+1)=250
    OLED_WR_DATA8(0x00);
    OLED_WR_DATA8(0x00);
    OLED_WR_DATA8(0x00);

    OLED_WR_REG(0x3C); //BorderWavefrom
    OLED_WR_DATA8(0x05);


//  OLED_WR_REG(0x21); //  Display update control
//  OLED_WR_DATA8(0x00);
//  OLED_WR_DATA8(0x80);

    OLED_WR_REG(0x18); //Read built-in temperature sensor
    OLED_WR_DATA8(0x80);

    OLED_WR_REG(0x4E);   // set RAM x address count to 0;
    OLED_WR_DATA8(0x00);
    OLED_WR_REG(0x4F);   // set RAM y address count to 0X199;
    OLED_WR_DATA8(0xC7);
    OLED_WR_DATA8(0x00);

    Epaper_READBUSY();

}

void Paint_NewImage(uint8_t *image,uint16_t Width,uint16_t Height,uint16_t Rotate,uint16_t Color)
{
    Paint.Image = 0x00;
    Paint.Image = image;

    Paint.WidthMemory = Width;
    Paint.HeightMemory = Height;
    Paint.Color = Color;
    Paint.WidthByte = (Width % 8 == 0)? (Width / 8 ): (Width / 8 + 1);
    Paint.HeightByte = Height;
    Paint.Rotate = Rotate;
    if(Rotate == ROTATE_0 || Rotate == ROTATE_180) {
        Paint.Width = Width;
        Paint.Height = Height;
    } else {
        Paint.Width = Height;
        Paint.Height = Width;
    }
}

void Paint_SetPixel(uint16_t Xpoint,uint16_t Ypoint,uint16_t Color)
{
    uint16_t X;
    uint16_t Y;
    uint32_t Addr;
    uint32_t Rdata;
    switch(Paint.Rotate)
    {
        case 0:
            X = Xpoint;
            Y = Ypoint;
            break;
        case 90:
            X = Paint.WidthMemory - Ypoint - 1;
            Y = Xpoint;
            break;
        case 180:
            X = Paint.WidthMemory - Xpoint - 1;
            Y = Paint.HeightMemory - Ypoint - 1;
            break;
        case 270:
            X = Ypoint;
            Y = Paint.HeightMemory - Xpoint - 1;
            break;
        default:
            return;
    }
    Addr = X / 8 + Y * Paint.WidthByte;
    Rdata = Paint.Image[Addr];
    if(Color == BLACK)
    {
        Paint.Image[Addr] = Rdata & ~(0x80 >> (X % 8)); //将对应数据位置0
    }
    else
        Paint.Image[Addr] = Rdata | (0x80 >> (X % 8));   //将对应数据位置1
}

//清屏函数
void OLED_Clear(uint16_t Color)
{
    uint16_t X,Y;
    uint32_t Addr;
    for (Y = 0; Y < Paint.HeightByte; Y++)
    {
        for (X = 0; X < Paint.WidthByte; X++)
        {
            //8 pixel =  1 byte
            Addr = X + Y*Paint.WidthByte;
            Paint.Image[Addr] = Color;
        }
    }
}

//画点函数
void OLED_Draw_Point(uint16_t Xpoint,uint16_t Ypoint,uint16_t Color)
{
    Paint_SetPixel(Xpoint - 1,Ypoint - 1,Color);
}

//更新到现存
void OLED_Display(unsigned char *Image)
{
    unsigned int Width = 200;
    unsigned int Height = 25;
    unsigned int i;
    unsigned int j;
    uint32_t k = 0;
    OLED_WR_REG(0X24);
    for (int j = 0; j < Height; j++)
    {
        for (int i = 0; i < Width; i++)
        {
            OLED_WR_DATA8(Image[k]);
            k++;
        }
    }
    EPD_Update();
}

//画直线
void OLED_DrawLine(uint16_t Xstart,uint16_t Ystart,uint16_t Xend,uint16_t Yend,uint16_t Color)
{
    uint16_t Xpoint, Ypoint;
    int dx, dy;
    int XAddway,YAddway;
    int Esp;
    char Dotted_Len;
    Xpoint = Xstart;
    Ypoint = Ystart;
    dx = (int)Xend - (int)Xstart >= 0 ? Xend - Xstart : Xstart - Xend;
    dy = (int)Yend - (int)Ystart <= 0 ? Yend - Ystart : Ystart - Yend;

    XAddway = Xstart < Xend ? 1 : -1;
    YAddway = Ystart < Yend ? 1 : -1;

    Esp = dx + dy;
    Dotted_Len = 0;

    for (;;)
    {
        Dotted_Len++;
        OLED_Draw_Point(Xpoint, Ypoint, Color);
        if (2 * Esp >= dy)
        {
            if (Xpoint == Xend)
                break;
            Esp += dy;
            Xpoint += XAddway;
        }
        if (2 * Esp <= dx)
        {
            if (Ypoint == Yend)
                break;
            Esp += dx;
            Ypoint += YAddway;
        }
    }
}

//画矩形
void OLED_DrawRectangle(uint16_t Xstart,uint16_t Ystart,uint16_t Xend,uint16_t Yend,uint16_t Color,uint8_t mode)
{
    uint16_t i;
    if (mode)
    {
        for(i = Ystart; i < Yend; i++)
        {
            OLED_DrawLine(Xstart,i,Xend,i,Color);
        }
    }
    else
    {
        OLED_DrawLine(Xstart, Ystart, Xend, Ystart, Color);
        OLED_DrawLine(Xstart, Ystart, Xstart, Yend, Color);
        OLED_DrawLine(Xend, Yend, Xend, Ystart, Color);
        OLED_DrawLine(Xend, Yend, Xstart, Yend, Color);
    }
}


//画圆形
void OLED_DrawCircle(uint16_t X_Center,uint16_t Y_Center,uint16_t Radius,uint16_t Color,uint8_t mode)
{
    uint16_t Esp, sCountY;
    uint16_t XCurrent, YCurrent;
    XCurrent = 0;
    YCurrent = Radius;
    Esp = 3 - (Radius << 1 );
    if (mode) {
        while (XCurrent <= YCurrent ) { //Realistic circles
            for (sCountY = XCurrent; sCountY <= YCurrent; sCountY ++ ) {
                OLED_Draw_Point(X_Center + XCurrent, Y_Center + sCountY, Color);//1
                OLED_Draw_Point(X_Center - XCurrent, Y_Center + sCountY, Color);//2
                OLED_Draw_Point(X_Center - sCountY, Y_Center + XCurrent, Color);//3
                OLED_Draw_Point(X_Center - sCountY, Y_Center - XCurrent, Color);//4
                OLED_Draw_Point(X_Center - XCurrent, Y_Center - sCountY, Color);//5
                OLED_Draw_Point(X_Center + XCurrent, Y_Center - sCountY, Color);//6
                OLED_Draw_Point(X_Center + sCountY, Y_Center - XCurrent, Color);//7
                OLED_Draw_Point(X_Center + sCountY, Y_Center + XCurrent, Color);
            }
            if ((int)Esp < 0 )
                Esp += 4 * XCurrent + 6;
            else {
                Esp += 10 + 4 * (XCurrent - YCurrent );
                YCurrent --;
            }
            XCurrent ++;
        }
    } else { //Draw a hollow circle
        while (XCurrent <= YCurrent ) {
            OLED_Draw_Point(X_Center + XCurrent, Y_Center + YCurrent, Color);//1
            OLED_Draw_Point(X_Center - XCurrent, Y_Center + YCurrent, Color);//2
            OLED_Draw_Point(X_Center - YCurrent, Y_Center + XCurrent, Color);//3
            OLED_Draw_Point(X_Center - YCurrent, Y_Center - XCurrent, Color);//4
            OLED_Draw_Point(X_Center - XCurrent, Y_Center - YCurrent, Color);//5
            OLED_Draw_Point(X_Center + XCurrent, Y_Center - YCurrent, Color);//6
            OLED_Draw_Point(X_Center + YCurrent, Y_Center - XCurrent, Color);//7
            OLED_Draw_Point(X_Center + YCurrent, Y_Center + XCurrent, Color);//0
            if ((int)Esp < 0 )
                Esp += 4 * XCurrent + 6;
            else {
                Esp += 10 + 4 * (XCurrent - YCurrent );
                YCurrent --;
            }
            XCurrent ++;
        }
    }
}

//显示字符
void OLED_ShowChar(uint16_t x,uint16_t y,uint16_t chr,uint16_t size1,uint16_t color)
{
    uint16_t i,m,temp,size2,chr1;
    uint16_t x0,y0;
    x+=1,y+=1,x0=x,y0=y;
    if(size1==8)size2=6;
    else size2=(size1/8+((size1%8)?1:0))*(size1/2);  //????×???????×?·????????ó???ù????×?????
    chr1=chr-' ';  //?????????ó????
    for(i=0;i<size2;i++)
    {
        if(size1==8)
        {temp=asc2_0806[chr1][i];} //?÷??0806×???
        else if(size1==12)
        {temp=asc2_1206[chr1][i];} //?÷??1206×???
        else if(size1==16)
        {temp=asc2_1608[chr1][i];} //?÷??1608×???
        else if(size1==24)
        {temp=asc2_2412[chr1][i];} //?÷??2412×???
        else return;
        for(m=0;m<8;m++)
        {
            if(temp&0x01)OLED_Draw_Point(x,y,color);
            else OLED_Draw_Point(x,y,!color);
            temp>>=1;
            y++;
        }
        x++;
        if((size1!=8)&&((x-x0)==size1/2))
        {x=x0;y0=y0+8;}
        y=y0;
    }
}

//显示字符串
//x,y:起点坐标
//size1：字体大小
//*chr:字符串起始地址
//mode:0,反色显示；1，正常显示
void OLED_ShowString(uint16_t x,uint16_t y,uint8_t *chr,uint16_t size1,uint16_t color)
{
    while(*chr!='\0')//ÅÐ¶ÏÊÇ²»ÊÇ·Ç·¨×Ö·û!
    {

        OLED_ShowChar(x,y,*chr,size1,color);
        chr++;
        x+=size1/2;
    }
}

//m^n
uint32_t OLED_Pow(uint16_t m,uint16_t n)
{
    uint32_t result=1;
    while(n--)
    {
        result*=m;
    }
    return result;
}

//显示数字
//x,y:起点坐标
//size1：字体大小
//num:要显示的数字
//len:数字的位数
//mode:0,反色显示；1，正常显示
void OLED_ShowNum(uint16_t x,uint16_t y,uint32_t num,uint16_t len,uint16_t size1,uint16_t color)
{
    uint8_t t;
    uint8_t temp;
    uint8_t m=0;
    if(size1==8)
    {
        m=2;
    }
    for(t=0;t<len;t++)
    {
        temp=(num/OLED_Pow(10,len-t-1))%10;
        if(temp==0)
        {
            OLED_ShowChar(x+(size1/2+m)*t,y,'0',size1,color);
        }
        else
        {
            OLED_ShowChar(x+(size1/2+m)*t,y,temp+'0',size1,color);
        }
    }
}

//显示汉字
//x,y:坐标起点
//num:汉字对应的序号
//mode:0,反色显示；1，正常显示
void OLED_ShowChinese(uint16_t x,uint16_t y,uint16_t num,uint16_t size1,uint16_t color)
{
    uint16_t m, temp;
    uint16_t x0, y0;
    uint16_t i, size3 = (size1 / 8 + ((size1 % 8) ? 1 : 0)) * size1;  //µÃµ½×ÖÌåÒ»¸ö×Ö·û¶ÔÓ¦µãÕó¼¯ËùÕ¼µÄ×Ö½ÚÊý
    x += 1, y += 1, x0 = x, y0 = y;
    for (i = 0; i < size3; i++)
    {
        if (size1 == 16)
        { temp = Hzk1[num][i]; }//µ÷ÓÃ16*16×ÖÌå
        else if (size1 == 24)
        { temp = Hzk2[num][i]; }//µ÷ÓÃ24*24×ÖÌå
        else if (size1 == 32)
        { temp = Hzk3[num][i]; }//µ÷ÓÃ32*32×ÖÌå
        else if (size1 == 64)
        { temp = Hzk4[num][i]; }//µ÷ÓÃ64*64×ÖÌå
        else return;
        for (m = 0; m < 8; m++)
        {
            if (temp & 0x01)OLED_Draw_Point(x, y, color);
            else OLED_Draw_Point(x, y, !color);
            temp >>= 1;
            y++;
        }
        x++;
        if ((x - x0) == size1)
        {
            x = x0;
            y0 = y0 + 8;
        }
        y = y0;
    }
}

//显示图片
//x,y起点坐标
//sizex:图片宽度
//sizey:图片长度
//BMP：图片数组
//mode:图片显示的数组
void OLED_ShowPicture(uint16_t x,uint16_t y,uint16_t sizex,uint16_t sizey,const uint8_t BMP[],uint16_t Color)
{
    uint16_t j=0;
    uint16_t i,n,temp,m;
    uint16_t x0,y0;
    x+=1,y+=1,x0=x,y0=y;
    sizey=sizey/8+((sizey%8)?1:0);
    for(n=0;n<sizey;n++)
    {
        for(i=0;i<sizex;i++)
        {
            temp=BMP[j];
            j++;
            for(m=0;m<8;m++)
            {
                if(temp&0x01)OLED_Draw_Point(x,y,Color);
                else OLED_Draw_Point(x,y,!Color);
                temp>>=1;
                y++;
            }
            x++;
            if((x-x0)==sizex)
            {
                x=x0;
                y0=y0+8;
            }
            y=y0;
        }
    }
}







