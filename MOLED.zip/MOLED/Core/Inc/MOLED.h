#ifndef __MOLED_H
#define __MOLED_H

#include "stdlib.h"
#include "main.h"
#include "gpio.h"

#define OLED_W   200
#define OLED_H   200


typedef struct
{
    uint8_t *Image;
    uint16_t Width;
    uint16_t Height;
    uint16_t WidthMemory;
    uint16_t HeightMemory;
    uint16_t Color;
    uint16_t Rotate;
    uint16_t WidthByte;
    uint16_t HeightByte;
} PAINT;
extern PAINT Paint;

#define ROTATE_0            0   //ÆÁÄ»ÕýÏòÏÔÊ¾
#define ROTATE_90           90  //ÆÁÄ»Ðý×ª90¶ÈÏÔÊ¾
#define ROTATE_180          180 //ÆÁÄ»Ðý×ª180¶ÈÏÔÊ¾
#define ROTATE_270          270 //ÆÁÄ»Ðý×ª270¶ÈÏÔÊ¾


#define WHITE          0xFF   //ÏÔÊ¾°×É«
#define BLACK          0x00   //ÏÔÊ¾ºÚÉ«

void OLED_GPIOInit(void);   //³õÊ¼»¯GPIO
void OLED_WR_Bus(uint8_t dat);   //Ä£ÄâSPIÊ±Ðò
void OLED_WR_REG(uint8_t reg);   //Ð´ÈëÒ»¸öÃüÁî
void OLED_WR_DATA8(uint8_t dat); //Ð´ÈëÒ»¸ö×Ö½Ú
void OLED_AddressSet(uint16_t xs,uint16_t ys,uint16_t xe,uint16_t ye);  //ÉèÖÃÎ»ÖÃº¯Êý
void OLED_Init(void);       //³õÊ¼»¯ÆÁÄ»

void Epaper_READBUSY(void);
void EPD_Update(void);

void Paint_NewImage(uint8_t *image,uint16_t Width,uint16_t Height,uint16_t Rotate,uint16_t Color);
void OLED_Clear(uint16_t Color);
void OLED_Draw_Point(uint16_t Xpoint,uint16_t Ypoint,uint16_t Color);
void OLED_DrawLine(uint16_t Xstart,uint16_t Ystart,uint16_t Xend,uint16_t Yend,uint16_t Color);
void OLED_DrawRectangle(uint16_t Xstart,uint16_t Ystart,uint16_t Xend,uint16_t Yend,uint16_t Color,uint8_t mode);
void OLED_DrawCircle(uint16_t X_Center,uint16_t Y_Center,uint16_t Radius,uint16_t Color,uint8_t mode);
void OLED_ShowChar(uint16_t x,uint16_t y,uint16_t chr,uint16_t size1,uint16_t color);
void OLED_ShowString(uint16_t x,uint16_t y,uint8_t *chr,uint16_t size1,uint16_t color);
void OLED_ShowNum(uint16_t x,uint16_t y,uint32_t num,uint16_t len,uint16_t size1,uint16_t color);
void OLED_ShowChinese(uint16_t x,uint16_t y,uint16_t num,uint16_t size1,uint16_t color);
void OLED_ShowPicture(uint16_t x,uint16_t y,uint16_t sizex,uint16_t sizey,const uint8_t BMP[],uint16_t color);
void OLED_Display(unsigned char *Image);
void OLED_GUIInit(void);


#endif

