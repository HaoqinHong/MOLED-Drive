#ifndef __MOLEDFONT_H
#define __MOLEDFONT_H
#include "main.h"

extern unsigned char asc2_0806[][6];
extern unsigned char asc2_1206[95][12];
extern unsigned char asc2_1608[][16];
extern unsigned char asc2_2412[][36];
extern unsigned char Hzk1[][32];
extern unsigned char Hzk2[][72];
extern unsigned char Hzk3[][128];
extern unsigned char Hzk4[][512];

#endif